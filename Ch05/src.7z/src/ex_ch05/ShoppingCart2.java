/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex_ch05;

/**
 *
 * @author Icey Thugg
 */
public class ShoppingCart2 {
  
  public static void main(String[] args) {;
       String custName = "Mary Smith"; 
       String message = custName+ " wants to purchase several items.";
    
       String[] items = {"tshirt","trousers","scarf","belt"};
       message = custName+ " wants to purchase " + items.length + " items.";
       
       System.out.println(message);
       System.out.println(items[0]);
       
  
       
  }
  }
    
    
    
    
    
    
    
  






